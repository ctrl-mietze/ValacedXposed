(() => {
  const native=valenced.modules.native;
  let settings,active=false,timer=null,revision=0,status={};
  let config={preferStereo:true,routePreference:"auto"};
  const listeners=new Set();
  function update(s){status=s||{};for(const f of listeners)f(++revision)}
  function inspect(){try{update(native.callNativeMethodSync("vexcord.audio.route",[]))}catch{update({note:"backend-unavailable"})}}
  function configure(){
    try{update(native.callNativeMethodSync("vexcord.audio.configure",[!!config.preferStereo,config.routePreference]))}
    catch{update({note:"backend-unavailable"})}
  }
  function set(p){config={...config,...p};settings?.set(config).catch(()=>{});configure()}
  function SettingsComponent(){
    const {React,ReactNative:RN}=valenced.react;
    const [,refresh]=React.useState(0);
    React.useEffect(()=>{listeners.add(refresh);inspect();return()=>listeners.delete(refresh)},[]);
    const h=React.createElement,T=RN.Text,V=RN.View;
    const label=status.note==="le-selected"?"LE Audio ausgewählt":status.note==="a2dp-sco-suppressed"||status.note==="a2dp-mode-request"?"A2DP-Priorität · Route testen":status.note==="backend-unavailable"?"Vexcord-Update erforderlich":status.note==="le-requested"?"LE Audio angefordert":status.note==="idle"?"Bereit · nächster Anruf":String(status.note||"Bereit");
    const choices=[["auto","Automatisch","LE Audio bevorzugen, sonst A2DP"],["a2dp","Stereo + Telefonmikrofon","SCO unterdrücken, klassische Medienroute"],["le","LE Audio","Nur echte LE-Kommunikationsgeräte"]];
    return h(RN.ScrollView,{style:{flex:1,backgroundColor:"#10111a"},contentContainerStyle:{padding:18}},
      h(T,{style:{color:"#c9b3ff",fontSize:24,fontWeight:"800"}},"Stereo Call 1.1"),
      h(T,{style:{color:"#bab3ca",marginTop:6}},"Native Android-Audio-Engine"),
      h(V,{style:{backgroundColor:"#1c2030",borderRadius:18,padding:16,marginVertical:18}},
        h(T,{style:{color:"#85e6ca",fontWeight:"600"}},label),
        h(T,{style:{color:"#bcb7cd",marginTop:8}},"Native Hooks: "+(status.backend||0)+" · Aufrufe: "+(status.hookHits||0)),
        h(T,{style:{color:"#bcb7cd",marginTop:5}},"A2DP: "+(status.a2dp?"ja":"nein")+" · LE-Kommunikation: "+(status.leAudio?"ja":"nein")),
        h(T,{style:{color:"#bcb7cd",marginTop:5}},"Android-Modus: "+String(status.mode??"?")+" · Kommunikationsgerät: "+String(status.communicationType??"?"))),
      h(V,{style:{paddingVertical:12,flexDirection:"row",alignItems:"center"}},
        h(T,{style:{color:"#f1eaff",flex:1,fontSize:16}},"Stereo-Priorität"),
        h(RN.Switch,{value:!!config.preferStereo,onValueChange:v=>set({preferStereo:v})})),
      ...choices.map(([key,name,sub])=>h(RN.Pressable,{key,onPress:()=>set({routePreference:key}),style:{padding:14,borderRadius:12,marginVertical:5,backgroundColor:config.routePreference===key?"#41335e":"#202234"}},
        h(T,{style:{color:"#f1eaff",fontSize:15,fontWeight:"600"}},name),
        h(T,{style:{color:"#bcb7cd",fontSize:12,marginTop:4}},sub))),
      h(RN.Pressable,{onPress:()=>set({preferStereo:false}),style:{padding:14,borderRadius:12,backgroundColor:"#302a48",marginTop:14}},
        h(T,{style:{color:"#e7dcff",textAlign:"center",fontWeight:"600"}},"Standardrouting wiederherstellen")),
      h(T,{style:{color:"#aaa2b9",fontSize:12,marginTop:18}},"Nach Profilwechsel den Discord-Anruf neu verbinden. A2DP und OpenSL ES garantieren nicht denselben Sprach-Ausgang; zuerst in einem Testanruf prüfen. Bei fehlendem Ton Standardrouting wählen. Keine systemweiten Hooks.")
    )
  }
  return {default:vexcord.definePlugin({
    async start(api){
      active=true;api.cleanup(()=>{active=false;if(timer)clearInterval(timer);timer=null;try{native.callNativeMethodSync("vexcord.audio.configure",[false,config.routePreference])}catch{}});
      settings=api.vexcord.storage.open("audio",{preferStereo:true,routePreference:"auto"});
      config={...config,...await settings.get()};if(!active)return;
      if(!["auto","a2dp","le"].includes(config.routePreference))config.routePreference="auto";
      configure();timer=setInterval(inspect,3000);
      nativeLoggingHook("[Vexcord Stereo] Native controller configured; backend="+(status.backend||0),1);
    },SettingsComponent
  })};
})()
